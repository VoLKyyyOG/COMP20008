variable = "This is super cool"
print(variable)
